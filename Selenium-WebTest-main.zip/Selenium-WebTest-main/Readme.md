
git status
git add .
git commit -m 'update'
git push origin main


git push origin main --force
git push --force

git pull --allow-unrelated-histories origin main

